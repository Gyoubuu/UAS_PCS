package com.aplikasi.apptokosi01.response.itemTransaksi

data class Data(
    val item_transaksi: ItemTransaksi
)