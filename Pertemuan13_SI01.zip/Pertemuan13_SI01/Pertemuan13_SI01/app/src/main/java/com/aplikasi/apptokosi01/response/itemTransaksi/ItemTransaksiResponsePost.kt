package com.aplikasi.apptokosi01.response.itemTransaksi

data class ItemTransaksiResponsePost(
    val `data`: Data,
    val message: String,
    val success: Boolean
)